ICCAD 2026 CAD Contest - Problem C - Alpha Test Submission

Contents:
- my_optimizer.py
- requirements.txt

Runtime environment expected by the organizers:
- Debian GNU/Linux 13
- Python 3.13.x
- No internet access during evaluation

Install dependencies if needed:
  pip install -r requirements.txt

Evaluation entry:
  python iccad2026_evaluate.py --evaluate my_optimizer.py

Notes:
- The submission is provided as source code fallback.
- The optimizer class is defined in my_optimizer.py.
